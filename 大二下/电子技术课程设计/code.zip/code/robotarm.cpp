/*************************************************************************
【文件名】                 robotarm.cpp
【功能模块和目的】          机械臂类，可以控制机械臂的运动，实现抓取、扫描和放置功能
【开发者】                 刘若涵，吴晓晴
【更改记录】
*************************************************************************/
#include "robotarm.h"

/*************************************************************************
【函数名称】        RobotArm
【函数功能】        构造函数
【参数】           无
【返回值】         无
【开发者】         刘若涵，吴晓晴
【更改记录】
*************************************************************************/
RobotArm::RobotArm()
{
  for (int i = 0; i < 3; i++)
  {
    for (int j = 0; j < 3; j++)
    {
      chess[i][j] = 0;
    }
  }
}
/*************************************************************************
【函数名称】        goback
【函数功能】        控制机械臂回到初始状态
【参数】           无
【返回值】         无
【开发者】         刘若涵，吴晓晴
【更改记录】
*************************************************************************/
void RobotArm::goback()
{
  servoc.write(80);
  servob.write(90);
  servoa.write(90);
  servoq.write(141);                        //初始状态x=11.3,y=0,z=10.7
}
/*************************************************************************
【函数名称】        moveto
【函数功能】        输入三维直角系坐标，机械臂的钳运动到指定三维坐标
【参数】           直角系坐标（x,y,z）
【返回值】         无
【开发者】         刘若涵，吴晓晴
【更改记录】
*************************************************************************/
void RobotArm::moveto(float x, float y, float z)
{
  float d = sqrt(x * x + y * y) - 4;
  float r = sqrt(d * d + (z - 3.1) * (z - 3.1));
  float a;                                      //a,b,c分别为为a,b,c舵机旋转角度
  float b;
  float c; 
  float b1, b2;
  float c1, c2;
  float gamma = 180 / 3.14 * asin((-4.47 - r * r) / 15.2 / r);
  float phi;                                 
  float beta = 180 / 3.14 * asin((4.47 - r * r) / 14.6 / r);
  float psai;
  int flag = 0;                                 //flag用于标志是否有可行解
  
  if ((z - 3.1) > 0)                          //cos(phi)<0，phi取-3Π/2-Π/2
  {
    phi = -180 / 3.14 * atan(d / (z - 3.1)) - 180; //phi属于-3pi/2到-pi/2
    c1 = (gamma - phi);
    c2 = -180 - (gamma + phi);
  }
  else
  {
    phi = -180 / 3.14 * atan(d / (z - 3.1)); //phi属于-pi/2到pi/2
    c1 = (gamma - phi);
    c2 = 180 - (gamma + phi);
  }


  if (d > 0) //cos(ksai)<0，ksai取-3Π/2-Π/2
  {
    psai = -180 / 3.14 * atan((z - 3.1) / d - 180; //psai属于-3pi/2到-pi/2
    b1 = (beta - psai);
    b2 = -180 - (beta + psai);
  }
  else
  {
    psai = -180 / 3.14 * atan((z - 3.1) / d - 4)); //psai属于-pi/2到pi/2
    b2 = 180 - (beta + psai);
    b1 = (beta - psai);
  }
  //根据限制条件选择符合条件的解的组合
  if (b1 + c1 > 130 && b1 + c1 < 255 && b1 > 0 && b1 < 135 && c1 > 10 && c1 < 190)
  {
    b = b1;
    c = c1;
    flag = 1;
  }
  if (b1 + c2 > 130 && b1 + c2 < 255 && b1 > 0 && b1 < 135 && c2 > 10 && c2 < 190)
  {
    b = b1;
    c = c2;
    flag = 1;
  }
  if (b2 + c1 > 130 && b2 + c1 < 255 && b2 > 0 && b2 < 135 && c1 > 10 && c1 < 190)
  {
    b = b2;
    c = c1;
    flag = 1;
  }
  if (b2 + c2 > 130 && b2 + c2 < 255 && b2 > 0 && b2 < 135 && c2 > 10 && c2 < 190)
  {
    b = b2;
    c = c2;
    flag = 1;
  }
  //求解a的值
  if (x > 0)
  {
    a = (180 / 3.14 * atan(y / x) + 225) / 250 * 180;
  }
  else
  {
    a = (180 / 3.14 * atan(y / x) + 45) / 250 * 180;
  }
  if (flag == 1 && a >= 0 && a <= 180)
  {
    servoc.write(c - 10);
    servob.write(b);
    servoa.write(a);
  }
  else
  {
    Serial.println("ERROR");
  }
}

/*************************************************************************
【函数名称】        ultrasonic
【函数功能】        超声波测距函数，返回超声波测距值
【参数】            无
【返回值】          double型的超声波测距得到的距离
【开发者】         刘若涵，吴晓晴
【更改记录】
*************************************************************************/

double RobotArm::ultrasonic()
{ 
  double distance, time1, time2;                       //测量两次取平均值以增大数据可信度
  servoq.write(60);                                    //机械臂钳子张开以方便测距
  digitalWrite(Trig, LOW);
  delayMicroseconds(2);
  digitalWrite(Trig, HIGH);
  delayMicroseconds(10);                               //产生一个10us的高脉冲去触发SR04
  digitalWrite(Trig, LOW);

  time1 = double(pulseIn(Echo, HIGH));                 // 检测脉冲宽度，注意返回值是微秒us
  delay(200);
  digitalWrite(Trig, LOW);
  delayMicroseconds(2);
  digitalWrite(Trig, HIGH);
  delayMicroseconds(10);                              //产生一个10us的高脉冲去触发SR04
  digitalWrite(Trig, LOW);
  time2 = double(pulseIn(Echo, HIGH)); 

  
  distance = (time1 + time2)/2 * 17 / 1000 ;          //计算出距离,输出的距离的单位是厘米cm
  return distance;
}

/*************************************************************************
【函数名称】        myxmoveto
【函数功能】        机械臂钳子以指定步长在X轴方向上的移动
【参数】            起点坐标（x0, y, z），终点的x坐标x1,步长steplength
【返回值】          无
【开发者】          刘若涵，吴晓晴
【更改记录】
*************************************************************************/

void RobotArm::myxmoveto(float x0, float y, float z, float x1, float steplength)
{
  float x = x0;
  if (x0 <= x1)                                   //根据x0与x1的大小关系分类讨论，实现一条轴方向上的指定步长的移动
  {
    for (; x + steplength < x1; x = x + steplength)    //每次只移动steplength长度
    {
      moveto(x, y, z);                            
      delay(100);
    }

  }
  else
  {
    for (; x - steplength > x1; x = x - steplength)
    {
      moveto(x, y, z);
      delay(100);
    }
  }
  moveto(x1, y, z);

}

/*************************************************************************
【函数名称】        myymoveto
【函数功能】        机械臂钳子以指定步长在y轴方向上的移动
【参数】            起点坐标（x, y0, z），终点的y坐标y1,步长steplength
【返回值】          无
【开发者】          刘若涵，吴晓晴
【更改记录】
*************************************************************************/

void RobotArm::myymoveto(float x, float y0, float z, float y1, float steplength)
{
  float y = y0;
  if (y0 < y1)                                       //根据y0与y1的大小关系分类讨论，实现一条轴方向上的指定步长的移动
  {
    for (; y + steplength < y1; y = y + steplength)   //每次只移动steplength长度
    {
      moveto(x, y, z);
      delay(100);
    }
  }
  else
  {
    for (; y - steplength > y1; y = y - steplength)
    {
      moveto(x, y, z);
      delay(100);
    }
  }

  moveto(x, y1, z);
}

/*************************************************************************
【函数名称】        myzmoveto
【函数功能】        机械臂钳子以指定步长在z轴方向上的移动
【参数】            起点坐标（x, y, z0），终点的z坐标z1,步长steplength
【返回值】          无
【开发者】          刘若涵，吴晓晴
【更改记录】
*************************************************************************/


void RobotArm::myzmoveto(float x, float y, float z0, float z1, float steplength)
{
  float z = z0;
  if (z0 < z1)                                  //根据z0与z1的大小关系分类讨论，实现一条轴方向上的指定步长的移动
  {
    for (; z + steplength < z1; z = z + steplength)    //每次只移动steplength长度  
    {
      moveto(x, y, z);
      delay(100);
    }
  }
  else
  {
    for (; z - steplength > z1; z = z - steplength)
    {
      moveto(x, y, z);
      delay(100);
    }
  }
  moveto(x, y, z1);
}

/*************************************************************************
【函数名称】        ifexist
【函数功能】        当机械臂钳子在已知z坐标为h时，根据超声波测距函数判断下方是否存在棋子
【参数】           机械臂钳子的z坐标为h
【返回值】          bool型变量，true表示存在棋子，false表示不存在棋子
【开发者】          刘若涵，吴晓晴
【更改记录】
*************************************************************************/

bool RobotArm::ifexist(float h)
{
  double distance;
  delay(200);
  distance = ultrasonic();                    //使用超声波函数测距
  return (distance < (h));
}


/*************************************************************************
【函数名称】        scan
【函数功能】        根据所给编号，机械臂进行扫描，判断是否存在棋子并将结果存到chess里
【参数】            编号num
【返回值】          无
【开发者】          刘若涵，吴晓晴
【更改记录】
*************************************************************************/

void RobotArm::scan(int num)                                  // 编号方式 1       6
{                                                             //         2       5
                                                              //         3       4
  servoq.write(60);
  if (num < 4)
  {
    moveto(11, 0, 7.7);
    delay(500);
    if (ifexist(7.7) && chess[num - 1][0] == 0)             //当这个地方的棋子为0且探测到有棋子时，认为这是对方所下，将chess的这个数值改成1，表示对方棋子
    {
      chess[num - 1][0] = 1;
    }
  }
  else
  {
    moveto(11, 0, 7.7);
    delay(500);
    if (ifexist(7.7) && chess[6 - num][2] == 0)
    {
      chess[6 - num][2] = 1;
    }
    delay(500);
    moveto(17, 0, 7.7);
    delay(500);
    if (ifexist(7.7) && chess[6 - num][1] == 0)
    {
      chess[6 - num][1] = 1;
    }
  }
  delay(500);
  goback();                                                          //回到初始状态
  delay(500);
}

/*************************************************************************
【函数名称】        findcenter1
【函数功能】        根据钳子目前所在位置，找到棋子圆心后将坐标返回
【参数】           钳子目前坐标（x0,y0,z0），存储棋子圆心坐标的数组center[3]
【返回值】          无
【开发者】          刘若涵，吴晓晴
【更改记录】
*************************************************************************/

void RobotArm::findcenter1(float x0, float y0, float z0, float center[3])
{
  servoq.write(60);
  float y1 = y0;
  int u = 0;
  for (; u < 2; y1 = y1 + 0.2)                     //在y轴方向上找到两个在圆心上的点
  {
    moveto(x0, y1, z0);
    delay(100);
    if(!ifexist(z0))
    {
      u++;
    }
  }
  moveto(x0, y0, z0);
  delay(100);
  float y2 = y0;
  int v = 0;
  for (; v < 2; y2 = y2 - 0.2)
  {
    moveto(x0, y2, z0);
    delay(100);
    if(!ifexist(z0))
    {
      v++;
    }
  }
  float y = (y1 + y2) / 2;                               //移动到找到的那两个点的中点
  moveto(x0, y, z0);
  delay(100);
  float x1 = x0;
  int w = 0;
  for (; w < 2; x1 = x1 + 0.2)                     //再沿x轴正方向移动，直至刚刚出圆
  {
    moveto(x1, y, z0);
    delay(100);
    if(!ifexist(z0))
    {
      w++;
    }
  }
  float x = x1 - 1.5;                                   //得到圆心坐标
  center[0] = x;
  center[1] = y;
  center[2] = z0;
}

/*************************************************************************
【函数名称】        findcenter2
【函数功能】        根据钳子目前所在位置，找到棋子圆心后将坐标返回
【参数】           钳子目前坐标（x0,y0,z0），存储棋子圆心坐标的数组center[3]
【返回值】          无
【开发者】          刘若涵，吴晓晴
【更改记录】
*************************************************************************/


void RobotArm::findcenter2(float x0, float y0, float z0, float center[3])
{
  servoq.write(60);
  float y1 = y0;
  int u = 0;
  for (; u < 2; y1 = y1 + 0.2)              //在y轴方向上找到两个在圆心上的点
  {
    moveto(x0, y1, z0);
    delay(100);
    if(!ifexist(z0))
    {
      u++;
    }
  }
  moveto(x0, y0, z0);
  delay(100);
  float y2 = y0;
  int v = 0;
  for (; v < 2; y2 = y2 - 0.2)
  {
    moveto(x0, y2, z0);
    delay(100);
    if(!ifexist(z0))
    {
      v++;
    }
  }
  float y = (y1 + y2) / 2;                       //移动到找到的那两个点的中点
  moveto(x0, y, z0);
  delay(100);
  float x2 = x0;
  int w = 0;
  for (; w < 2; x2 = x2 - 0.2)              //再沿x轴负方向移动，直至刚刚出圆
  {
    moveto(x2, y, z0);
    delay(100);
    if(!ifexist(z0))
    {
      w++;
    }
  }
  float x = x2 + 1.5;                  
  center[0] = x;                         //得到圆心坐标
  center[1] = y;
  center[2] = z0;
}


/*************************************************************************
【函数名称】        grabinboard
【函数功能】        抓取棋盘格的棋子
【参数】           int d，d=0表示抓近的那一格中的棋子，d=1表示抓远的那一格中的棋子
【返回值】          无
【开发者】          刘若涵，吴晓晴
【更改记录】
*************************************************************************/

void RobotArm::grabinboard(int d)   
{
  servoc.write(80);
  servob.write(90);
  servoa.write(162);
  servoq.write(141);//初始状态y=11.3,x=0,z=10.7
  delay(500);
  if (d == 0)            //离得近的那一格
  {
    float center[3];
    moveto(8.5, 0, 7.5);
    delay(200);
    servoq.write(60);
    delay(500);
    float x = 8.5;
    for (; !ifexist(7.5) && x < 13; x = x + 0.5)       //先沿x轴负方向移动到可以扫到棋子的地方
    {
      moveto(x, 0, 7.5);
      delay(500);
    }
    if(x < 13)
    {
      moveto(x + 1, 0, 7.5);
      delay(500);
      findcenter1(x + 1, 0, 7.5, center);          //先找到圆心
      delay(200);
      moveto(center[0] - 0.5, center[1], center[2]);
      delay(200);
      myzmoveto(center[0] - 0.5, center[1], center[2], 3.5, 0.5);   // 移动到圆心
      delay(200); 
      servoq.write(140);                                //抓取
      delay(200);
      moveto(center[0] - 0.5, center[1], 11);
      delay(200);
    }
    goback();
  }
  else                  //离得远的那一格
  {
    float center[3];
    moveto(15, 0, 6.5);
    delay(200);
    servoq.write(60);
    delay(500);
    float x = 15;
    for (; !ifexist(6.5) && x < 17.5 ; x = x + 0.5)       //先沿x轴负方向移动到可以扫到棋子的地方
    {
      moveto(x, 0, 6.5);
      delay(500);
    }
    if( x < 17.5)
    {
      moveto(x + 1, 0, 6.5);
      delay(500);
      findcenter2(x + 1, 0, 6.5, center);              //先找到圆心
      delay(200);
      moveto(center[0] + 2, center[1], center[2]);
      delay(200);
      myzmoveto(center[0] + 2, center[1], center[2], 4, 0.5);       // 移动到圆心
      delay(200);
      servoq.write(140);                               //抓取
      delay(200);
      moveto(center[0] + 2, center[1], 9);
      delay(200);
      moveto(15, center[1], 11);
      delay(200);
    }
    goback();
  }
}

/*************************************************************************
【函数名称】        grabinzone
【函数功能】        抓取放置区的棋子
【参数】           无
【返回值】          无
【开发者】          刘若涵，吴晓晴
【更改记录】
*************************************************************************/

void RobotArm::grabinzone()   //抓棋放置区的棋子
{
  float center[3];
  moveto(-9, 0, 7.5);
  delay(200);
  servoq.write(60);
  delay(500);
  float x = -9;
  for (; !ifexist(7.5) && x > -17; x = x - 1)       //先沿x轴负方向移动到可以扫到棋子的地方
  {
    moveto(x, 0, 7.5);
    delay(500);
  }
  if(x > -17)
  {
    moveto(x - 1, 0, 7.5);
  delay(500);
  findcenter2(x - 1, 0, 7.5, center);       //找到棋子圆心
  delay(200);
  moveto(center[0] + 1, center[1], center[2]);
  delay(200);
  myzmoveto(center[0] + 1, center[1], center[2], 3.5, 0.5);
  delay(200);
  servoq.write(140);
  delay(200);
  moveto(center[0] + 1, center[1], 11);
  delay(200);
  }
  goback();
}

/*************************************************************************
【函数名称】        placeinboard
【函数功能】        抓将棋子放到棋盘格内
【参数】           int num，num=0表示将棋子放到近的那一格，d=1表示将棋子放到远的那一格
【返回值】          无
【开发者】          刘若涵，吴晓晴
【更改记录】
*************************************************************************/

void RobotArm::placeinboard(int num)
{
  if (num == 0)
  {
    moveto(11, 0, 7.5);
    delay(500);
    myzmoveto(11, 0, 7.5, 3.8, 0.5);
    delay(1000);
    servoq.write(80);
    delay(500);
    moveto(11, 0, 7.5);
    delay(500);
    goback();
  }
  else
  {
    moveto(15, 0, 11);
    delay(500);
    moveto(17, 0, 9);
    delay(500);
    myzmoveto(17, 0, 9, 3.8, 0.5);
    delay(1000);
    servoq.write(80);
    delay(500);
    moveto(17, 0, 9);
    delay(500);
    goback();
  }
}

/*************************************************************************
【函数名称】        placeinzone
【函数功能】        抓将棋子放到放置区内
【参数】           无
【返回值】          无
【开发者】          刘若涵，吴晓晴
【更改记录】
*************************************************************************/

void RobotArm::placeinzone()
{
  moveto(-15, 0, 11);
  delay(500);
  myzmoveto(-15, 0, 11, 3.8, 0.5);
  delay(1000);
  servoq.write(80);
  delay(500);
  moveto(-15, 0, 7.5);
  delay(500);
  goback();
}
