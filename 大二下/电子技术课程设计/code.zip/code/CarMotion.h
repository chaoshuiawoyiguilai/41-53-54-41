/*************************************************************************
【文件名】                CarMotion.h
【功能模块和目的】         核心类头文件 小车运动类声明
【开发者及日期】           赵永奇、毛静嘉
*************************************************************************/
#ifndef CARMOTION_H_
#define CARMOTION_H_
#include <Servo.h>
#include <Arduino.h>

class CarMotion {
public:
    int count ; //计数
    int diffAngle; //差速角
    int delay_time; //差速保持时间
    Servo serR;  //定义右驱动
    Servo serL;  //定义左驱动
    
    int infBackVal_1;
    int infBackVal_2;
    int infBackVal_4;
    int infBackVal_5;
    
    int infForeVal_1;
    int infForeVal_2;
    int infForeVal_4;
    int infForeVal_5; //传感器

    CarMotion(); //构造函数
    void senRenew(); //传感器更新数据
    
    //直行部分
    void go_straight();//小车直行
    void turn_L(int delay_time, int angle);//小车左转
    void turn_R(int delay_time, int angle);//小车右转

    //倒退部分
    void car_back();//小车后退
    void back_L(int delay_time, int angle);//小车倒退左转
    void back_R(int delay_time, int angle);//小车倒退右转

    void car_stop();//小车停止

    void foreStopLine(int line1, int line2); //前进方向从某线到某线停下
    void backStopLine(int line1, int line2); //后退方向从某线到某线停下
    
    void foreTracking();//直走循迹
    void backTracking();//倒退循迹

    //void MotionCycle(); //前进
};

#endif
