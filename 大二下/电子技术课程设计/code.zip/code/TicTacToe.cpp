/*************************************************************************
【文件名】                TicTacToe.cpp
【功能模块和目的】         井字棋类，实现井字棋策略功能
【开发者及日期】           毛静嘉、赵永奇
【更改记录】
*************************************************************************/

#include "TicTacToe.h"
//#include <iostream>
//using namespace std;

//静态成员初始化
int TicTacToe::gameTime = 0;
int TicTacToe::winTime = 0;

/*************************************************************************
【函数名称】        TicTacToe()
【函数功能】        构造函数
【参数】           无
【返回值】         无
【开发者】         毛静嘉、赵永奇
【更改记录】       
*************************************************************************/
TicTacToe::TicTacToe() {
  for (int i = 0; i < 9; i++) {
    chessman[i] = 0;
  }
  first = 0;
  result = 0;
  order = 0;
  gameTime++; //总棋局数增加
}

/*************************************************************************
【函数名称】        renew(const int(&chess)[9])
【函数功能】        更新棋局信息
【参数】           const int(&chess)[9]（新的棋局信息）
【返回值】         无
【开发者】         毛静嘉、赵永奇
【更改记录】       
*************************************************************************/
void TicTacToe::renew(const int(&chess)[9]) {
  for (int i = 0; i < 9; i++) {
    if (chess[i] != 0 && chessman[i] == 0) { //当外界信息有更新
      if (order == 0) {
        first = 1; //说明是对方先手
      }
      order++;
      chessman[i] = order;
    }
  }
}

/*************************************************************************
【函数名称】        play()
【函数功能】        根据下棋策略返回下一步棋的位置
【参数】           无
【返回值】         int型（下一步棋的位置）
【开发者】         毛静嘉、赵永奇
【更改记录】       
*************************************************************************/
int TicTacToe::play() {
  if (first == 0) {
    if (order == 0) {//说明未下过棋，直接下在第一个位置
      order++; chessman[0] = order; return 0; //下在第0个位置
    }
    else { //说明我自己的第一个下在了chessman[0] = 1

      if (chessman[4] == 2) { //对手选择下在中间
        if (order == 2) {//说明轮到自己的第二步 即第三个棋子还未放下
          order++; chessman[8] = order; return 8; //下在第8个位置
        }
        else { //说明自己已经下过第三个棋子
          if (chessman[2] == 4) { //说明对手占领角落
            if (order == 4) {//轮到自己的第三步
              order++; chessman[6] = order; return 6;
            }
            else {
              if (chessman[3] == 0) { //对手没有堵住3号位置
                result = 1; //胜利
                order++; chessman[3] = order; return 3; //下在3号位置
              }
              else {
                result = 1; //胜利
                order++; chessman[7] = order; return 7; //否则下在7号位置
              }
            }
          }
          else if (chessman[6] == 4) { //说明对手占领角落
            if (order == 4) {//轮到自己的第三步
              order++; chessman[2] = order; return 2;
            }
            else {
              if (chessman[1] == 0) { //对手没有堵住1号位置
                result = 1; //胜利
                order++; chessman[1] = order; return 1; //下在1号位置
              }
              else {
                result = 1; //胜利
                order++; chessman[5] = order; return 5; //否则下在5号位置
              }
            }
          }
          else { //对手占领其他位置 此时其实结果已定 但需要在最后一步棋才给出平局结果
            if (order == 8) {//在最后一个下的时候给出平局结果（最后一个棋是小车下）
              order++; chessman[3] = order; result = 3;
            }
            if (chessman[1] % 2 == 1 && chessman[2] == 0) { //自己赢
              result = 1;
              order++; chessman[2] = order; return 2;
            }
            else if (chessman[2] % 2 == 1 && chessman[1] == 0) {
              result = 1;
              order++; chessman[1] = order; return 1;
            }
            else if (chessman[2] % 2 == 1 && chessman[5] == 0) {
              result = 1;
              order++; chessman[5] = order; return 5;
            }
            else if (chessman[5] % 2 == 1 && chessman[2] == 0) {
              result = 1;
              order++; chessman[2] = order; return 2;
            }
            else if (chessman[3] % 2 == 1 && chessman[6] == 0) {
              result = 1;
              order++; chessman[6] = order; return 6;
            }
            else if (chessman[6] % 2 == 1 && chessman[3] == 0) {
              result = 1;
              order++; chessman[3] = order; return 3;
            }
            else if (chessman[6] % 2 == 1 && chessman[7] == 0) {
              result = 1;
              order++; chessman[7] = order; return 7;
            }
            else if (chessman[7] % 2 == 1 && chessman[6] == 0) {
              result = 1;
              order++; chessman[6] = order; return 6;
            }
            else if (chessman[1] % 2 == 0 && chessman[1] != 0 && chessman[7] == 0) { //堵对方
              order++; chessman[7] = order; return 7;
            }
            else if (chessman[7] % 2 == 0 && chessman[7] != 0 && chessman[1] == 0) {
              order++; chessman[1] = order; return 1;
            }
            else if (chessman[3] % 2 == 0 && chessman[3] != 0 && chessman[5] == 0) {
              order++; chessman[5] = order; return 5;
            }
            else if (chessman[5] % 2 == 0 && chessman[5] != 0 && chessman[3] == 0) {
              order++; chessman[3] = order; return 3;
            }
            else if (chessman[2] % 2 == 0 && chessman[2] != 0 && chessman[6] == 0) {
              order++; chessman[6] = order; return 6;
            }
            else if (chessman[6] % 2 == 0 && chessman[6] != 0 && chessman[2] == 0) {
              order++; chessman[2] = order; return 2;
            } //应该并不需要else了 以上应包含所有情况 需要仔细检查
          }
        }
      }
      else if (chessman[1] == 2) { //对手 紧贴 
        if (order == 2) {//说明轮到自己的第二步 即第三个棋子还未放下
          order++; chessman[6] = order; return 6; //下在6号
        }
        else {
          if (chessman[3] == 4) {//对方下在了3号
            if (order == 4) {
              order++; chessman[8] = order; return 8;
            }
            else { //
              if (chessman[4] == 0) { //对方未堵4
                result = 1;
                order++; chessman[4] = order; return 4; //取得胜利
              }
              else { //对方堵住4
                result = 1;
                order++; chessman[7] = order; return 7; //取得胜利
              }
            }
          }
          else { //对方没有堵
            result = 1;
            order++; chessman[3] = order; return 3; //下在3号，取得胜利
          }
        }
      }
      else if (chessman[3] == 2) {
        if (order == 2) {//说明轮到自己的第二步 即第三个棋子还未放下
          order++; chessman[2] = order; return 2; //下在2号
        }
        else {
          if (chessman[1] == 4) {//对方下在了1号
            if (order == 4) {
              order++; chessman[8] = order; return 8;
            }
            else { //
              if (chessman[4] == 0) { //对方没有堵住7号
                result = 1;
                order++; chessman[4] = order; return 4; //取得胜利
              }
              else { //对方堵住7号
                result = 1;
                order++; chessman[5] = order; return 5; //取得胜利
              }
            }
          }
          else { //对方没有堵
            result = 1;
            order++; chessman[1] = order; return 1; //下在1号，取得胜利
          }
        }
      }

      else if (chessman[2] == 2) { //对手 接近
        if (order == 2) { //说明轮到自己的第二步 即第三个棋子还未放下
          order++; chessman[6] = order; return 6; //下在6号
        }
        else {
          if (chessman[3] == 4) {//对方下在了3号
            if (order == 4) {
              order++; chessman[8] = order; return 8;
            }
            else { //
              if (chessman[4] == 0) {
                result = 1;
                order++; chessman[4] = order; return 4; //取得胜利
              }
              else {
                result = 1;
                order++; chessman[7] = order; return 7; //取得胜利
              }
            }
          }
          else { //对方没有堵
            result = 1;
            order++; chessman[3] = order; return 3; //下在3号，取得胜利
          }
        }
      }
      else if (chessman[6] == 2) {
        if (order == 2) { //说明轮到自己的第二步 即第三个棋子还未放下
          order++; chessman[2] = order; return 2; //下在2号
        }
        else {
          if (chessman[1] == 4) {//对方下在了1号
            if (order == 4) {
              order++; chessman[8] = order; return 8;
            }
            else { //
              if (chessman[4] == 0) {
                result = 1;
                order++; chessman[4] = order; return 4; //取得胜利
              }
              else {
                result = 1;
                order++; chessman[5] = order; return 5; //取得胜利
              }
            }
          }
          else { //对方没有堵
            result = 1;
            order++; chessman[1] = order; return 1; //下在1号，取得胜利
          }
        }
      }

      else if (chessman[5] == 2) { //对手 靠近
        if (order == 2) {//说明轮到自己的第二步 即第三个棋子还未放下
          order++; chessman[2] = order; return 2; //下在2号
        }
        else {
          if (chessman[1] == 4) {//对方下在了1号
            if (order == 4) {
              order++; chessman[6] = order; return 6;
            }
            else { //
              if (chessman[3] == 0) {
                result = 1;
                order++; chessman[3] = order; return 3; //取得胜利
              }
              else {
                result = 1;
                order++; chessman[4] = order; return 4; //取得胜利
              }
            }
          }
          else { //对方没有堵
            result = 1;
            order++; chessman[1] = order; return 1; //下在1号，取得胜利
          }
        }
      }
      else if (chessman[7] == 2) {
        if (order == 2) {//说明轮到自己的第二步 即第三个棋子还未放下
          order++; chessman[6] = order; return 6; //下在6号
        }
        else {
          if (chessman[3] == 4) {//对方下在了1号
            if (order == 4) {
              order++; chessman[2] = order; return 2;
            }
            else { //
              if (chessman[1] == 0) {
                result = 1;
                order++; chessman[1] = order; return 1; //取得胜利
              }
              else {
                result = 1;
                order++; chessman[4] = order; return 4; //取得胜利
              }
            }
          }
          else { //对方没有堵
            result = 1;
            order++; chessman[3] = order; return 3; //下在1号，取得胜利
          }
        }
      }

      else { //对手远离 即chessman[8] == 2
        if (order == 2) {//说明轮到自己的第二步 即第三个棋子还未放下
          order++; chessman[6] = order; return 6; //下在6号
        }
        else {
          if (chessman[3] == 4) {//对方下在了3号
            if (order == 4) {
              order++; chessman[2] = order; return 2;
            }
            else { //
              if (chessman[1] == 0) {
                result = 1;
                order++; chessman[1] = order; return 1; //取得胜利
              }
              else {
                result = 1;
                order++; chessman[4] = order; return 4; //取得胜利
              }
            }
          }
          else { //对方没有堵
            result = 1;
            order++; chessman[3] = order; return 3; //下在1号，取得胜利
          }
        }
      }
    }
  }
  else {
    //人第一步棋下在中间（5）
    if (chessman[4] == 1) {  //说明对方第一个下在中间（4）
      if (order == 1) {  //后手时，奇数表示对方，偶数表示小车，小车下第一步棋
        order++; chessman[6] = order; return 6;           //返回第一步棋位置6
      }
      else if (chessman[2] == 3) {  //对方已下两个棋子，轮到自己下第二个棋子
        if (order == 7) { //下满棋局 //记得在下完后要给自己order+1 相当于此时自己是第八个下的
          order++; chessman[3] = order; result = 3;
        }
        if (order == 3) {   //对方第二个棋子下在位置2
          order++; chessman[0] = order; return 0;    //小车第二个棋子下在位置0
        }
        else if (chessman[3] == 5) {//对方第3个棋下在位置3
          if (order == 5) {          //轮到小车下第3个棋子
            order++; chessman[5] = order; return 5;      //小车第三个棋下在位置5堵住
          }
          else {           //双方都已下三个棋，小车堵位置
            if (order == 7)
              result = 3; //是否需要返回值？
            if (chessman[1] % 2 != 0 && chessman[7] % 2 == 0) {
              order++; chessman[7] = order; return 7;
            }
            else if (chessman[7] % 2 != 0 && chessman[1] % 2 == 0) {
              order++; chessman[1] = order; return 1;
            }
            else if (chessman[8] % 2 != 0 && chessman[1] % 2 == 0) {
              order++; chessman[1] = order; return 1;
            }
            else if (chessman[8] % 2 != 0 && chessman[7] % 2 == 0) {
              order++; chessman[7] = order; return 7;
            }
          }
        }
        else {
          result = 1;             //小车胜利
          order++; chessman[3] = order; return 3;              //返回小车第三个棋子
        }
      }
      else {              //如果对方第二个棋子不下在位置2，情况太多了
        if (order == 7) { //下满棋局 //记得在下完后要给自己order+1 相当于此时自己是第八个下的
          result = 3;
        }
        if (chessman[0] % 2 == 0 && chessman[0] != 0 && chessman[3] == 0) { //自己赢
          result = 1;
          order++; chessman[3] = order; return 3;
        }
        else if (chessman[3] % 2 == 0 && chessman[3] != 0 && chessman[0] == 0) { //自己赢
          result = 1;
          order++; chessman[0] = order; return 0;
        }
        else if (chessman[7] % 2 == 0 && chessman[7] != 0 && chessman[8] == 0) { //自己赢
          result = 1;
          order++; chessman[8] = order; return 8;
        }
        else if (chessman[8] % 2 == 0 && chessman[8] != 0 && chessman[7] == 0) { //自己赢
          result = 1;
          order++; chessman[7] = order; return 7;
        }
        else if (chessman[0] % 2 == 1 && chessman[8] == 0) { //堵对方
          order++; chessman[8] = order; return 8;
        }
        else if (chessman[8] % 2 == 1 && chessman[0] == 0) { //堵对方
          order++; chessman[0] = order; return 0;
        }
        else if (chessman[1] % 2 == 1 && chessman[7] == 0) { //堵对方
          order++; chessman[7] = order; return 7;
        }
        else if (chessman[7] % 2 == 1 && chessman[1] == 0) { //堵对方
          order++; chessman[1] = order; return 1;
        }
        else if (chessman[3] % 2 == 1 && chessman[5] == 0) { //堵对方
          order++; chessman[5] = order; return 5;
        }
        else if (chessman[5] % 2 == 1 && chessman[3] == 0) { //堵对方
          order++; chessman[3] = order; return 3;
        }

      }
    }
    else {     //对方第一个棋不在中间，小车第一个棋就下在中间
      if (order == 1) {
        order++; chessman[4] = order; return 4;
      }
      else {
        if (order == 7) {
          result = 3;
        }
        //小车胜利八种情况
        if ((chessman[0] % 2 == 0 && chessman[0] != 0) && chessman[8] == 0) {
          result = 1;  //小车胜利
          order++; chessman[8] = order; return 8;
        }
        else if ((chessman[8] % 2 == 0 && chessman[8] != 0) && chessman[0] == 0) {
          result = 1;  //小车胜利
          order++; chessman[0] = order; return 0;
        }
        else if ((chessman[1] % 2 == 0 && chessman[1] != 0) && chessman[7] == 0) {
          result = 1;  //小车胜利
          order++; chessman[7] = order; return 7;
        }
        else if ((chessman[7] % 2 == 0 && chessman[7] != 0) && chessman[1] == 0) {
          result = 1;  //小车胜利
          order++; chessman[1] = order; return 1;
        }
        else if ((chessman[2] % 2 == 0 && chessman[2] != 0) && chessman[6] == 0) {
          result = 1;  //小车胜利
          order++; chessman[6] = order; return 6;
        }
        else if ((chessman[6] % 2 == 0 && chessman[6] != 0) && chessman[2] == 0) {
          result = 1;  //小车胜利
          order++; chessman[2] = order; return 2;
        }
        else if ((chessman[3] % 2 == 0 && chessman[3] != 0) && chessman[5] == 0) {
          result = 1;  //小车胜利
          order++; chessman[5] = order; return 5;
        }
        else if ((chessman[5] % 2 == 0 && chessman[5] != 0) && chessman[3] == 0) {
          result = 1;  //小车胜利
          order++; chessman[3] = order; return 3;
        }

        //小车堵对方有12种情况
        else if (chessman[0] % 2 == 1 && chessman[1] % 2 == 1 && chessman[2] == 0) {
          order++; chessman[2] = order; return 2;
        }
        else if (chessman[0] % 2 == 1 && chessman[2] % 2 == 1 && chessman[1] == 0) {
          order++; chessman[1] = order; return 1;
        }
        else if (chessman[1] % 2 == 1 && chessman[2] % 2 == 1 && chessman[0] == 0) {
          order++; chessman[0] = order; return 0;
        }

        else if (chessman[0] % 2 == 1 && chessman[3] % 2 == 1 && chessman[6] == 0) {
          order++; chessman[6] = order; return 6;
        }
        else if (chessman[0] % 2 == 1 && chessman[6] % 2 == 1 && chessman[3] == 0) {
          order++; chessman[3] = order; return 3;
        }
        else if (chessman[3] % 2 == 1 && chessman[6] % 2 == 1 && chessman[0] == 0) {
          order++; chessman[0] = order; return 0;
        }

        else if (chessman[2] % 2 == 1 && chessman[5] % 2 == 1 && chessman[8] == 0) {
          order++; chessman[8] = order; return 8;
        }
        else if (chessman[2] % 2 == 1 && chessman[8] % 2 == 1 && chessman[5] == 0) {
          order++; chessman[5] = order; return 5;
        }
        else if (chessman[5] % 2 == 1 && chessman[8] % 2 == 1 && chessman[2] == 0) {
          order++; chessman[2] = order; return 2;
        }

        else if (chessman[6] % 2 == 1 && chessman[7] % 2 == 1 && chessman[8] == 0) {
          order++; chessman[8] = order; return 8;
        }
        else if (chessman[6] % 2 == 1 && chessman[8] % 2 == 1 && chessman[7] == 0) {
          order++; chessman[7] = order; return 7;
        }
        else if (chessman[7] % 2 == 1 && chessman[8] % 2 == 1 && chessman[6] == 0) {
          order++; chessman[6] = order; return 6;
        }
        //其他
        else {
          for (int i = 0; i < 9; i++) {
            if (chessman[i] == 0)
              order++; chessman[i] = order; return i;
          }
        }
      }
    }
  }
}


/*************************************************************************
【函数名称】        IsGameOver()
【函数功能】        判断是否游戏结束
【参数】           无
【返回值】         bool型
【开发者】         毛静嘉、赵永奇
【更改记录】       
*************************************************************************/
bool TicTacToe::IsGameOver() {
  if (result == 0 || (result == 3 && order < 9))
    return false;
  else
    return true;
}

/*************************************************************************
【函数名称】        IsPlaceUsed(int place)
【函数功能】        int place（想下的地方）
【参数】           无
【返回值】         bool型
【开发者】         毛静嘉、赵永奇
【更改记录】       
*************************************************************************/
bool TicTacToe::IsPlaceUsed(int place){
  if(chessman[place] == 0) {//没下过
    order++;
    chessman[place] = order;
    return true;
  }
  else{
    return false;
  }
}
