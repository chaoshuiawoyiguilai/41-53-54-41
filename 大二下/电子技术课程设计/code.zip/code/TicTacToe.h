/*************************************************************************
【文件名】                TicTacToe.h
【功能模块和目的】         核心类头文件 井字棋类声明
【开发者及日期】           毛静嘉、赵永奇
*************************************************************************/

#ifndef TICTACTOE_H
#define TICTACTOE_H

class TicTacToe
{
public:
  //数据成员
  int chessman[9]; //储存九个棋子的棋盘
  int first; //是否先手 0是小车先手
  int result; //棋局结果 0进行中 1赢 2输 3平局
  int order; //进行到第几步
  //静态
  static int gameTime; //总棋局次数
  static int winTime; //自己（小车）赢的总次数 //暂时还未更新

  //成员函数
  TicTacToe(); //构造函数
  void renew(const int (&chess)[9]); //从外界更新棋盘信息
  int play(); //下一步棋，返回下的棋子的序号（0~8）
  bool IsGameOver(); //判断棋局是否结束
  bool IsPlaceUsed(int place); //判断是否该位置已经下过
};

#endif
