/*************************************************************************
【文件名】                robotarm.h
【功能模块和目的】         核心类头文件 机械臂类声明
【开发者及日期】           刘若涵 吴晓晴
*************************************************************************/
#ifndef  ROBOTARM_H_
#define  ROBOTARM_H_
#include <Arduino.h>
#include <Servo.h>
class RobotArm
{
  public:
    //机械臂a轴
    Servo servoa;
    //机械臂b轴
    Servo servob;
    //机械臂c轴，
    Servo servoc;
    //机械臂钳子
    Servo servoq;
    //棋盘，用于记忆棋局
    int chess[3][3];
    //超声波探头Trig接口
    int Trig;
    //超声波探头Echo接口
    int Echo;
    //构造函数
    RobotArm();
    //回到初始状态
    void goback();
    //移动到指定坐标
    void moveto(float x, float y, float z);
    //x轴方向慢速移动
    void myxmoveto(float x0, float y, float z, float x1, float steplength);
    //y轴方向慢速移动
    void myymoveto(float x, float y0, float z, float y1, float steplength);
    //z轴方向慢速移动
    void myzmoveto(float x, float y, float z0, float z1, float steplength);
    //超声波测距
    double ultrasonic();
    //判断是否扫描到棋子
    bool ifexist(float h);
    //扫描
    void scan(int num);
    //寻找较近一格棋子的中点坐标
    void findcenter1(float x0, float y0, float z0,float center[3]);
    //寻找较远一格棋子的中点坐标
    void findcenter2(float x0, float y0, float z0,float center[3]);
    //抓取棋盘中的棋子
    void grabinboard(int d);
    //抓取放置区的棋子
    void grabinzone();
    //将棋子放置到棋盘中
    void placeinboard(int num);
    //将棋子放置到放置区
    void placeinzone();
};
#endif
