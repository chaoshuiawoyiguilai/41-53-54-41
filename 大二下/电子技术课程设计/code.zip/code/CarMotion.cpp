/*************************************************************************
【文件名】                CarMotion.cpp
【功能模块和目的】         小车类声明，实现小车的运动、在定位线处停车、循迹
【开发者及日期】           赵永奇、毛静嘉
【更改记录】
*************************************************************************/

#include "CarMotion.h"

//从左到右1-5 后红外传感
#define infBackSenPin_1 36
#define infBackSenPin_2 34
#define infBackSenPin_4 32
#define infBackSenPin_5 30
//前
#define infForeSenPin_1 28
#define infForeSenPin_2 26
#define infForeSenPin_4 24
#define infForeSenPin_5 22

//构造函数初始化
CarMotion::CarMotion() {
    count = 0;
    diffAngle = 5;
    delay_time = 35;
    
    int infBackVal_1 = 0;
    int infBackVal_2 = 0;
    int infBackVal_4 = 0;
    int infBackVal_5 = 0;
    
    int infForeVal_1 = 0;
    int infForeVal_2 = 0;
    int infForeVal_4 = 0;
    int infForeVal_5 = 0;
}

/*************************************************************************
【函数名称】        senRenew
【函数功能】        小车红外传感的输入值更新
【参数】           无
【返回值】         无
【开发者】         赵永奇、毛静嘉
【更改记录】       
*************************************************************************/
void CarMotion::senRenew(){
    infBackVal_1 =digitalRead(infBackSenPin_1);
    infBackVal_2 =digitalRead(infBackSenPin_2);
    infBackVal_4 =digitalRead(infBackSenPin_4);
    infBackVal_5 =digitalRead(infBackSenPin_5);
    infForeVal_1 =digitalRead(infForeSenPin_1);
    infForeVal_2 =digitalRead(infForeSenPin_2);
    infForeVal_4 =digitalRead(infForeSenPin_4);
    infForeVal_5 =digitalRead(infForeSenPin_5);
}

/*************************************************************************
【函数名称】        go_straight
【函数功能】        直行
【参数】           无
【返回值】         无
【开发者】         赵永奇、毛静嘉
【更改记录】       
*************************************************************************/
void CarMotion::go_straight() {
    serL.write(360);
    serR.write(-360);
    delay(1);
}

/*************************************************************************
【函数名称】        turn_L
【函数功能】        向前左转
【参数】           int delay_time, int angle
【返回值】         无
【开发者】         赵永奇、毛静嘉
【更改记录】       
*************************************************************************/
void CarMotion::turn_L(int delay_time, int angle) {
    serL.write(70 + angle);
    serR.write(20 - angle);
    delay(1);
}

/*************************************************************************
【函数名称】        turn_R
【函数功能】        向前右转
【参数】           int delay_time, int angle
【返回值】         无
【开发者】         赵永奇、毛静嘉
【更改记录】       
*************************************************************************/
void CarMotion::turn_R(int delay_time, int angle) {
    serL.write(160 + angle);
    serR.write(70 + angle);
    delay(1);
}

/*************************************************************************
【函数名称】        car_back
【函数功能】        倒退
【参数】           无
【返回值】         无
【开发者】         赵永奇、毛静嘉
【更改记录】       
*************************************************************************/
void CarMotion::car_back() {
    serL.write(-360);
    serR.write(360);
    delay(1);
}

/*************************************************************************
【函数名称】        back_L
【函数功能】        控制小车倒车左转
【参数】           int delay_time（延迟时间）, int angle（控制差速）
【返回值】         无
【开发者】         赵永奇、毛静嘉
【更改记录】       加入了随着转弯时间不同差速不同的方法，使其在拐弯时更顺利
*************************************************************************/
void CarMotion::back_L(int delay_time, int angle) {
    serL.write(70 + angle); //随转角进行改变
    serR.write(160 + angle);
    delay(delay_time);
}

/*************************************************************************
【函数名称】        back_R
【函数功能】        控制小车倒退右转
【参数】           int delay_time, int angle
【返回值】         无
【开发者】         赵永奇、毛静嘉
【更改记录】       
*************************************************************************/
void CarMotion::back_R(int delay_time, int angle) {
    serL.write(20 - angle);
    serR.write(110 - angle);
    delay(delay_time);
}

/*************************************************************************
【函数名称】        car_stop
【函数功能】        停车
【参数】           无
【返回值】         无
【开发者】         赵永奇、毛静嘉
【更改记录】       
*************************************************************************/
void CarMotion::car_stop() {
    serL.write(90);
    serR.write(90);
    delay(1);
    
}

/*************************************************************************
【函数名称】        foreStopLine
【函数功能】        控制小车向前从某线到某线停下
【参数】           int line1（起始线）, int line2（终止线）
【返回值】         无
【开发者】         赵永奇、毛静嘉
【更改记录】       从原本的用delay控制脱出定位线改为flag状态控制，避免了被硬件影响
*************************************************************************/ 
void CarMotion::foreStopLine(int line1, int line2){
   senRenew();
   int cnt1 = 0;
   int diff1;
   int flag = 0;//设置一个标志
   diff1 = line2 - line1;
   for(;;){
    if(cnt1 < diff1){
      senRenew();
      if(flag ==0 && infForeVal_1 == 0 && infForeVal_5 == 0){
        cnt1++;
        flag = 1;
      }
      else if(flag ==1 && (infForeVal_1 == 1 || infForeVal_5 == 1)){
        flag = 0;
      }
      foreTracking();
    }
    else if(cnt1 == diff1){
      car_stop(); //停车
      break;
    }
   }
}

/*************************************************************************
【函数名称】        backStopLine
【函数功能】        控制小车向后从某线到某线停下
【参数】           int line1（起始线）, int line2（终止线）
【返回值】         无
【开发者】         赵永奇、毛静嘉
【更改记录】       从原本的用delay控制脱出定位线改为flag状态控制，避免了被硬件影响
*************************************************************************/ 
void CarMotion::backStopLine(int line1, int line2){
   senRenew();
   int cnt2 = 0;
   int diff2;
   int flag = 0;
   diff2 = line1 - line2;
   
   for(;;){
    if(cnt2 < diff2){
      senRenew();
 
      if(flag ==0 && infForeVal_1 == 0 && infForeVal_5 == 0){
        cnt2++;
        flag = 1;
      }
      else if(flag ==1 && (infForeVal_1 == 1 || infForeVal_5 == 1)){
        flag = 0;
      }
      backTracking();
    }
    else if(cnt2 == diff2){
      car_stop(); //停车
      break;
    }
   }
}
                             
/*************************************************************************
【函数名称】        foreTracking
【函数功能】        控制小车向前循迹
【参数】           无
【返回值】         无
【开发者】         赵永奇、毛静嘉
【更改记录】       加入差速角调整
*************************************************************************/ 
void CarMotion::foreTracking() {
    senRenew();
    //左转
    if (infForeVal_4 == 1 && infForeVal_2 == 0) {
        if (diffAngle < 20) { //差速调整
            diffAngle = diffAngle + 1;
        }
        turn_L(delay_time, diffAngle);
        senRenew();
    }
    //右转
    else if (infForeVal_2 == 1 && infForeVal_4 == 0) {
        if (diffAngle < 20) { //差速调整
            diffAngle = diffAngle + 1;
        }
        turn_R(delay_time, diffAngle);
        senRenew();
    }
    //直走
    else {
        go_straight();
        senRenew();
    }
}

/*************************************************************************
【函数名称】        backTracking
【函数功能】        控制小车向后循迹
【参数】           无
【返回值】         无
【开发者】         赵永奇、毛静嘉
【更改记录】       加入差速角调整
*************************************************************************/ 
void CarMotion::backTracking(){
    //左转
    if (infBackVal_4 == 1 && infBackVal_2 == 0) {
        if (diffAngle < 20) { //差速调整
            diffAngle = diffAngle + 1;
        }
        back_L(delay_time, diffAngle);
    }
    //右转
    else if (infBackVal_2 == 1 && infBackVal_4 == 0) {
        if (diffAngle < 20) { //差速调整
            diffAngle = diffAngle + 1;
        }
        back_R(delay_time, diffAngle);
    }
    //直走
    else {
        diffAngle = 5;
        car_back();
    }
}    
