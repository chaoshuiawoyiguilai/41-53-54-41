### 安装依赖
只需要首次运行前执行一次
```shell
pip install -r requirements.txt
```

### 运行
```shell
python main.py
```