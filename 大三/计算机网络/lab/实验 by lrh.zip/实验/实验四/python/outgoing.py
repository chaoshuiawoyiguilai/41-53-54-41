"""
这是等待你完成的代码。正常情况下，本文件是你唯一需要改动的文件。
你可以任意地改动此文件，改动的范围当然不限于已有的五个函数里。（只要已有函数的签名别改，要是签名改了main里面就调用不到了）
在开始写代码之前，请先仔细阅读此文件和api文件。这个文件里的五个函数是等你去完成的，而api里的函数是供你调用的。
提示：TCP是有状态的协议，因此你大概率，会需要一个什么样的数据结构来记录和维护所有连接的状态
"""
from api import *
from scapy.all import *
import time

my_link = dict() #以TCP连接四元组（源ip、端口号和目的IP、端口号）的字符串形式作为key的字典,用于存储现有连接

class TCP_link():
    def __init__(self, conn, state="CLOSED", seq_send=0, seq_ack=0, ack=0):
        self.state = state #连接状态
        self.conn = conn #连接四元组
        self.seq_send = seq_send #下次将要发送的报文段seq
        self.seq_ack = seq_ack #已经被确认按序接收的最大报文段seq
        self.ack = ack #期望从对方得到的报文段seq
        self.cache = [] #发送缓存
        self.waittime_start = 0 #TIME_WAIT状态开始时间

    def update_state(self, state): #更新TCP状态机状态
        self.state = state

    def rcv_msg(self, seq, ack): #接收报文时更新seq_ack，ack
        self.seq_ack = seq
        self.ack = ack

    def send_msg(self, seq, time, data): #发送报文段时，将报文段seq、发送时间、数据存入缓存，更新seq_send
        self.cache.append([self.seq_send, time, data])
        self.seq_send = seq

    def wait_start(self, time): #进入TIME_WAIT状态，记录开始时间
        self.waittime_start = time


def get_key(conn: ConnectionIdentifier): #将conn转换为可哈希的字符串形式，作为字典的key
    return str(conn["src"]["ip"]) + str(conn["src"]["port"]) + str(conn["dst"]["ip"]) + str(conn["dst"]["port"])


def app_connect(conn: ConnectionIdentifier):
    """
    当有应用想要发起一个新的连接时，会调用此函数。想要连接的对象在conn里提供了。
    你应该向想要连接的对象发送SYN报文，执行三次握手的逻辑。
    当连接建立好后，你需要调用app_connected函数，通知应用层连接已经被建立好了。
    :param conn: 连接对象
    :return:
    """
    # TODO 请实现此函数
    global my_link
    key = get_key(conn)
    # TCP报文的建立及校验和的计算通过scapy库进行，参考https://blog.csdn.net/friend_c/article/details/123363608
    # 构建数据包,SYN
    packet = IP(dst=conn["dst"]["ip"], src=conn["src"]["ip"]) / TCP(dport=conn["dst"]["port"],
                                                                    sport=conn["src"]["port"], flags="S")
    # 把数据包转换成byte，这时候会自动计算校验和
    packet_raw = raw(packet)
    # 得到TCP部分的byte
    data = packet_raw[20:]
    tcp_tx(conn, data) #发送TCP报文
    my_link[key] = TCP_link(conn, state="SYN_SENT")
    my_link[key].send_msg((packet[TCP].seq + 1) % 4294967296, time.time(), data)
    print("app_connect", conn)


def app_send(conn: ConnectionIdentifier, data: bytes):
    """
    当应用层想要在一个已经建立好的连接上发送数据时，会调用此函数。
    :param conn: 连接对象
    :param data: 数据内容，是字节数组
    :return:
    """
    # TODO 请实现此函数
    global my_link
    key = get_key(conn)
    # 构建数据包
    packet = IP(dst=conn["dst"]["ip"], src=conn["src"]["ip"]) / TCP(dport=conn["dst"]["port"],
                                                                    sport=conn["src"]["port"],
                                                                    seq=my_link[key].seq_send, ack=my_link[key].ack,
                                                                    flags="A") / data
    # 把数据包转换成byte，这时候会自动计算校验和
    packet_raw = raw(packet)
    # 得到TCP部分的byte
    data_sent = packet_raw[20:]
    tcp_tx(conn, data_sent)
    my_link[key].send_msg((my_link[key].seq_send + len(data)) % 4294967296, time.time(), data_sent)
    print("app_send", conn, data.decode(errors='replace'))


def app_fin(conn: ConnectionIdentifier):
    """
    当应用层想要半关闭连接(FIN)时，会调用此函数。
    :param conn: 连接对象
    :return:
    """
    # TODO 请实现此函数
    global my_link
    key = get_key(conn)
    # 构建数据包,FIN
    packet = IP(dst=conn["dst"]["ip"], src=conn["src"]["ip"]) / TCP(dport=conn["dst"]["port"],
                                                                    sport=conn["src"]["port"],
                                                                    seq=my_link[key].seq_send, ack=my_link[key].ack,
                                                                    flags="FA")
    # 把数据包转换成byte，这时候会自动计算校验和
    packet_raw = raw(packet)
    # 得到TCP部分的byte
    data_sent = packet_raw[20:]
    tcp_tx(conn, data_sent)
    my_link[key].send_msg((my_link[key].seq_send + 1) % 4294967296, time.time(), data_sent)
    if my_link[key].state == "ESTABLISHED":
        my_link[key].update_state("FIN_WAIT_1")
    elif my_link[key].state == "CLOSE_WAIT":
        my_link[key].update_state("LAST_ACK")
    print("app_fin", conn)


def app_rst(conn: ConnectionIdentifier):
    """
    当应用层想要重置连接(RES)时，会调用此函数
    :param conn: 连接对象
    :return:
    """
    # TODO 请实现此函数
    global my_link
    key = get_key(conn)
    # 构建数据包,RST
    packet = IP(dst=conn["dst"]["ip"], src=conn["src"]["ip"]) / TCP(dport=conn["dst"]["port"],
                                                                    sport=conn["src"]["port"],
                                                                    seq=my_link[key].seq_send, ack=my_link[key].ack,
                                                                    flags="R")
    # 把数据包转换成byte，这时候会自动计算校验和
    packet_raw = raw(packet)
    # 得到TCP部分的byte
    data_sent = packet_raw[20:]
    tcp_tx(conn, data_sent)
    del my_link[key] #删除连接
    print("app_rst", conn)


def tcp_rx(conn: ConnectionIdentifier, data: bytes):
    """
    当收到TCP报文时，会调用此函数。
    正常情况下，你会对TCP报文，根据报文内容和连接的当前状态加以处理，然后调用0个~多个api文件中的函数
    :param conn: 连接对象
    :param data: TCP报文内容，是字节数组。（含TCP报头，不含IP报头）
    :return:
    """
    # TODO 请实现此函数
    global my_link
    key = get_key(conn)
    # 获取标志符信息部分参考吴晓晴同学思路
    flag = bin(data[13])
    if len(flag) > 8:
        flag = flag[len(flag) - 6:]
    else:
        flag = flag[2:]
    ns = ''
    for i in range(6 - len(flag)):
        ns = ns + '0'
    ns = ns + flag  # ns为六位字符串，从0~5对应TCP报文头中的URG，ACK，PSH，RST，SYN，FIN位
    isURG = (ns[0] == '1')
    isACK = (ns[1] == '1')
    isPSH = (ns[2] == '1')
    isRST = (ns[3] == '1')
    isSYN = (ns[4] == '1')
    isFIN = (ns[5] == '1')

    seq_rcv = (data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7]
    if seq_rcv == my_link[key].ack: #接收到的报文段seq为期望的数值
        order = True
    else:
        order = False

    head_len = data[12] / 4 #TCP报文头部长度
    head_len = int(head_len)
    if len(data) > head_len: #有传输数据
        data_load = data[head_len:]
        has_load = True
    else: #无传输数据
        data_load = None
        has_load = False

    if isACK and isSYN and my_link[key].state == "SYN_SENT": #如果在SYN_SENT并且收到SYN+ACK，则发送ACK报文，更新状态为ESTABLISHED
        ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7] + 1) % 4294967296
        seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
        my_link[key].rcv_msg(seq, ack)
        # 构建数据包,ACK
        packet = IP(dst=conn["dst"]["ip"], src=conn["src"]["ip"]) / TCP(dport=conn["dst"]["port"],
                                                                        sport=conn["src"]["port"],
                                                                        seq=my_link[key].seq_send, ack=my_link[key].ack,
                                                                        flags="A")
        # 把数据包转换成byte，这时候会自动计算校验和
        packet_raw = raw(packet)
        # 得到TCP部分的byte
        data_sent = packet_raw[20:]
        tcp_tx(conn, data_sent)
        i = 0
        while i < len(my_link[key].cache): #将已确认接收的报文段从发送缓存中删除
            if my_link[key].cache[i][0] < my_link[key].seq_ack:
                del my_link[key].cache[i]
                i -= 1
            i += 1
        my_link[key].update_state("ESTABLISHED")
        app_connected(conn) #通知应用层连接已建立

    elif isRST: #如果收到RST报文，则直接删除连接
        del my_link[key]
        app_peer_rst(conn) #通知应用层对端想要重置连接

    elif isFIN and my_link[key].state == "ESTABLISHED" and order: #如果在ESTABLISHED状态收到FIN报文，则发送ACK报文，更新状态为CLOSE_WAIT
        if has_load: #如果同时有传输数据
            app_recv(conn, data_load) #将数据传给应用层
            ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7] + len(data_load)) % 4294967296
            seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
            my_link[key].rcv_msg(seq, ack)
        else:
            ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7] + 1) % 4294967296
            seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
            my_link[key].rcv_msg(seq, ack)
        # 构建数据包,ACK
        packet = IP(dst=conn["dst"]["ip"], src=conn["src"]["ip"]) / TCP(dport=conn["dst"]["port"],
                                                                        sport=conn["src"]["port"],
                                                                        seq=my_link[key].seq_send, ack=my_link[key].ack,
                                                                        flags="A")
        # 把数据包转换成byte，这时候会自动计算校验和
        packet_raw = raw(packet)
        # 得到TCP部分的byte
        data_sent = packet_raw[20:]
        tcp_tx(conn, data_sent)
        i = 0
        while i < len(my_link[key].cache): #将已确认接收的报文段从发送缓存中删除
            if my_link[key].cache[i][0] < my_link[key].seq_ack:
                del my_link[key].cache[i]
                i -= 1
            i += 1
        my_link[key].update_state("CLOSE_WAIT")

    if isACK and my_link[key].state == "LAST_ACK" and order: #如果在LAST_ACK状态收到ACK报文，则关闭连接
        ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7]) % 4294967296
        seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
        my_link[key].rcv_msg(seq, ack)
        my_link[key].update_state("CLOSED")
        release_connection(conn) #通知应用层释放连接
        del my_link[key]

    if isFIN and my_link[key].state == "FIN_WAIT_1" and order: #如果在FIN_WAIT_1状态收到FIN报文，则发送ACK报文，更新状态为CLOSING
        if has_load: #如果同时有传输数据
            app_recv(conn, data_load) #将数据传给应用层
            ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7] + len(data_load)) % 4294967296
            seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
            my_link[key].rcv_msg(seq, ack)
        else:
            ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7] + 1) % 4294967296
            seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
            my_link[key].rcv_msg(seq, ack)
        # 构建数据包,ACK
        packet = IP(dst=conn["dst"]["ip"], src=conn["src"]["ip"]) / TCP(dport=conn["dst"]["port"],
                                                                        sport=conn["src"]["port"],
                                                                        seq=my_link[key].seq_send, ack=my_link[key].ack,
                                                                        flags="A")
        # 把数据包转换成byte，这时候会自动计算校验和
        packet_raw = raw(packet)
        # 得到TCP部分的byte
        data_sent = packet_raw[20:]
        tcp_tx(conn, data_sent)
        i = 0
        while i < len(my_link[key].cache): #将已确认接收的报文段从发送缓存中删除
            if my_link[key].cache[i][0] < my_link[key].seq_ack:
                del my_link[key].cache[i]
                i -= 1
            i += 1
        my_link[key].update_state("CLOSING")

    if isACK and (not isFIN) and my_link[key].state == "CLOSING" and order: #如果在CLOSING状态收到ACK报文，则更新状态为TIME_WAIT
        if has_load: #如果同时有传输数据
            app_recv(conn, data_load) #将数据传给应用层
            ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7] + len(data_load)) % 4294967296
            seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
            my_link[key].rcv_msg(seq, ack)
        else:
            ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7]) % 4294967296
            seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
            my_link[key].rcv_msg(seq, ack)
        i = 0
        while i < len(my_link[key].cache): #将已确认接收的报文段从发送缓存中删除
            if my_link[key].cache[i][0] < my_link[key].seq_ack:
                del my_link[key].cache[i]
                i -= 1
            i += 1
        my_link[key].update_state("TIME_WAIT")
        my_link[key].wait_start(time.time())

    if isACK and (not isFIN) and my_link[key].state == "FIN_WAIT_1" and order: #如果在FIN_WAIT_1状态收到ACK报文，则更新状态为FIN_WAIT_2
        if has_load: #如果同时有传输数据
            app_recv(conn, data_load) #将数据传给应用层
            ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7] + len(data_load)) % 4294967296
            seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
            my_link[key].rcv_msg(seq, ack)
        else:
            ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7]) % 4294967296
            seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
            my_link[key].rcv_msg(seq, ack)
        i = 0
        while i < len(my_link[key].cache): #将已确认接收的报文段从发送缓存中删除
            if my_link[key].cache[i][0] < my_link[key].seq_ack:
                del my_link[key].cache[i]
                i -= 1
            i += 1
        my_link[key].update_state("FIN_WAIT_2")

    if isFIN and my_link[key].state == "FIN_WAIT_2" and order: #如果在FIN_WAIT_2状态收到FIN报文，则发送ACK报文，更新状态为TIME_WAIT
        if has_load: #如果同时有传输数据
            app_recv(conn, data_load) #将数据传给应用层
            ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7] + len(data_load)) % 4294967296
            seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
            my_link[key].rcv_msg(seq, ack)
        else:
            ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7] + 1) % 4294967296
            seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
            my_link[key].rcv_msg(seq, ack)
        # 构建数据包,ACK
        packet = IP(dst=conn["dst"]["ip"], src=conn["src"]["ip"]) / TCP(dport=conn["dst"]["port"],
                                                                        sport=conn["src"]["port"],
                                                                        seq=my_link[key].seq_send, ack=my_link[key].ack,
                                                                        flags="A")
        # 把数据包转换成byte，这时候会自动计算校验和
        packet_raw = raw(packet)
        # 得到TCP部分的byte
        data_sent = packet_raw[20:]
        tcp_tx(conn, data_sent)
        i = 0
        while i < len(my_link[key].cache): #将已确认接收的报文段从发送缓存中删除
            if my_link[key].cache[i][0] < my_link[key].seq_ack:
                del my_link[key].cache[i]
                i -= 1
            i += 1
        my_link[key].update_state("TIME_WAIT")
        my_link[key].wait_start(time.time())

    if isACK and (my_link[key].state == "ESTABLISHED" or my_link[key].state == "FIN_WAIT_2") and order: #如果在ESTABLISHED或FIN_WAIT_2状态收到普通报文
        if has_load: #如果有数据，发送ACK报文
            app_recv(conn, data_load) #将数据传给应用层
            ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7] + len(data_load)) % 4294967296
            seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
            my_link[key].rcv_msg(seq, ack)
            # 构建数据包,ACK
            packet = IP(dst=conn["dst"]["ip"], src=conn["src"]["ip"]) / TCP(dport=conn["dst"]["port"],
                                                                            sport=conn["src"]["port"],
                                                                            seq=my_link[key].seq_send,
                                                                            ack=my_link[key].ack, flags="A")
            # 把数据包转换成byte，这时候会自动计算校验和
            packet_raw = raw(packet)
            # 得到TCP部分的byte
            data_sent = packet_raw[20:]
            tcp_tx(conn, data_sent)
        else: #如果为纯ACK报文，更新seq_ack, ack和缓存
            ack = ((data[4] << 24) + (data[5] << 16) + (data[6] << 8) + data[7]) % 4294967296
            seq = ((data[8] << 24) + (data[9] << 16) + (data[10] << 8) + data[11]) % 4294967296
            my_link[key].rcv_msg(seq, ack)
        i = 0
        while i < len(my_link[key].cache): #将已确认接收的报文段从发送缓存中删除
            if my_link[key].cache[i][0] < my_link[key].seq_ack:
                del my_link[key].cache[i]
                i -= 1
            i += 1

    if (not order) and has_load: #如果接收到的报文段不为期望的seq，发送ACK报文
        # 构建数据包,ACK
        packet = IP(dst=conn["dst"]["ip"], src=conn["src"]["ip"]) / TCP(dport=conn["dst"]["port"],
                                                                        sport=conn["src"]["port"],
                                                                        seq=my_link[key].seq_send,
                                                                        ack=my_link[key].ack, flags="A")
        # 把数据包转换成byte，这时候会自动计算校验和
        packet_raw = raw(packet)
        # 得到TCP部分的byte
        data_sent = packet_raw[20:]
        tcp_tx(conn, data_sent)

    print("tcp_rx", conn, data.decode(errors='replace'))


def tick():
    """
    这个函数会每至少100ms调用一次，以保证控制权可以定期的回到你实现的函数中，而不是一直阻塞在main文件里面。
    它可以被用来在不开启多线程的情况下实现超时重传等功能，详见主仓库的README.md
    """
    # TODO 可实现此函数，也可不实现
    global my_link
    for key in my_link: #对于my_link中的每一个TCP连接
        for i in range(len(my_link[key].cache)): #对于发送缓存中的每一个报文段，若当前时间减去发送时间大于设定的阈值，则重发
            if time.time() - my_link[key].cache[i][1] > 1:
                tcp_tx(my_link[key].conn, my_link[key].cache[i][2])
                my_link[key].cache[i][1] = time.time()
        if my_link[key].state == "TIME_WAIT": #若在TIME_WAIT状态，当前时间减去TIME_WAIT开始时的时间若大于设定的阈值，则关闭连接
            if time.time() - my_link[key].waittime_start > 2:
                release_connection(my_link[key].conn) #通知应用层释放连接
                del my_link[key]
