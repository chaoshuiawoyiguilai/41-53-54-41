import socket
import threading
import datetime

def Connet():
    while True:
        connectionSocket, addr = serverSocket.accept()
        if addr not in clientSocket:
            time_now = str(datetime.datetime.now())
            print(time_now, ' 用户 [%s:%s] 进入了聊天室' % addr)
            connectionSocket.send((time_now + ' 欢迎来到聊天室!').encode())
            global num
            num = num + 1
            for clientaddr in clientSocket:
                clientSocket[clientaddr].send(('[' + str(addr[0]) + ':' + str(addr[1]) + '] ' + time_now + ' 进入了聊天室').encode())
            clientSocket[addr] = connectionSocket
            t = threading.Thread(target=Receive_message, args=(connectionSocket, addr), daemon=True)
            t.start()

def Receive_message(connectionSocket, addr):
    global num
    while True:
        try:
            if addr in clientSocket:
                time_now = str(datetime.datetime.now())
                sentence = connectionSocket.recv(1024).decode()
                if len(sentence) == 0:
                    # 返回的句子长度为0，说明对端已close
                    print(time_now, ' 用户 [%s:%s] 退出了聊天室' % addr)
                    connectionSocket.close()
                    clientSocket.pop(addr)
                    for clientaddr in clientSocket:
                        clientSocket[clientaddr].send(('[' + str(addr[0]) + ':' + str(addr[1]) + '] ' + time_now + ' 离开了聊天室').encode())
                    num = num - 1
                else:
                    print(time_now + '  用户 [' + str(addr[0]) + ':' + str(addr[1]) + '] 发表了 - ' + sentence)
                    connectionSocket.send(('[Me] ' + time_now + ' - ' + sentence).encode())
                    for clientaddr in clientSocket:
                        if clientSocket[clientaddr] != connectionSocket:
                            clientSocket[clientaddr].send(('[' + str(addr[0]) + ':' + str(addr[1]) + '] ' + time_now + ' - ' + sentence).encode())
        except BaseException as error:
            print('错误：', error)
            if addr in clientSocket:
                print(time_now, '用户 [%s:%s] 强行中断了连接' % addr)
                connectionSocket.close()
                clientSocket.pop(addr)
                num = num - 1
   

serverPort = 11111
serverAddr = '127.0.0.1'
serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serverSocket.bind((serverAddr, serverPort))
serverSocket.listen(1)
print('服务器 [' + str(serverAddr) + ':' + str(serverPort) + '] 开始运行')

num = 0
num_show = 0
clientSocket = {}

t1 = threading.Thread(target=Connet, daemon=True)
t1.start()

while True:
    sentence = input()
    if sentence == 'QUIT':
        serverSocket.close()
        break
    if num != num_show:
        print('当前在线人数为:', num)
        num_show = num
