import socket
import threading

serverName = '127.0.0.1'
serverPort = 11111
clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clientSocket.connect((serverName, serverPort))

def send_message():
    global Flag
    while Flag:
        sentence = input()
        if sentence == 'QUIT':
            clientSocket.close()
            break
        clientSocket.send(sentence.encode())

def receive_message():
    global Flag
    while True:
        sentence = clientSocket.recv(1024)
        if len(sentence) == 0:
            # 返回的句子长度为0，说明对端已close
            print('聊天室服务器关闭')
            Flag = False
            clientSocket.close()
            return
        print(sentence.decode())

# 开启上面定义的线程
clientThread = threading.Thread(target=receive_message,daemon=True)
clientThread.start()
Flag = True
send_message()