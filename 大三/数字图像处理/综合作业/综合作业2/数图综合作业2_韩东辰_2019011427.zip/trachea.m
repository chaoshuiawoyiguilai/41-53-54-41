addpath(".\SliceBrowser");
addpath(".\NIfTI_20140122");

trachea_segmentation(4);
trachea_segmentation(5);
trachea_segmentation(7);

function trachea_segmentation(number)
    %% 读入待处理的CT数据
    path = ['./data/coronacases_org_00', num2str(number), '.nii'];
    nii = load_nii(path);
    img = nii.img;
    
    %% 二维切片图像处理
    [m, n, p] = size(img);
    trachea_3D = zeros(m, n, p);
    for i = 2:p
        img_2D = img(:, :, i); 
        % 二值化
        img_2D = (img_2D > 0.6 * mean(mean(img_2D)));
        % 找到整个胸腔
        chest = find_max_domain(img_2D);
        % 找到气管
        trachea_2D = zeros(m, n);
        for j = 1 : 10
            in_chest = imfill(chest, 'hole') .* (~chest);
            temp = in_chest;
            trachea_2D_temp = imerode(in_chest, strel('disk', j));
            % 找到各个连通区域
            [imLabel, num] = bwlabel(trachea_2D_temp);
            % 求连通区域的大小
            stats = regionprops(imLabel, 'Area');    %求各连通域的大小
            area = cat(1, stats.Area);
            for k = 1 : num
                if area(k) > 500
                    the_area = ismember(imLabel, k);
                    trachea_2D_temp = trachea_2D_temp - the_area;
                end
            end
            trachea_2D_temp = imdilate(trachea_2D_temp, strel('disk', j)) .* temp;   
            trachea_2D = trachea_2D | trachea_2D_temp;
        end
        % 构建气管3D-CT图
        trachea_2D = trachea_2D';
        trachea_3D(1:m - 2, 1:n - 1, i - 1) = trachea_2D(3:m, 2:n);
    end
    
    %% 三维形态学操作
    % 进行图像腐蚀和膨胀
    trachea_3D = imerode(trachea_3D, strel('cube', 4));
    trachea_3D = imdilate(trachea_3D, strel('cuboid', [1, 1, 5]));
    trachea_3D = imerode(trachea_3D, strel('cuboid', [1, 1, 5]));
    % 删除错误的小区域
    CC = bwconncomp(trachea_3D, 26);
    list = CC.PixelIdxList;
    % 求所有连通区域的体积
    all_size = cellfun(@numel, list);
    max_size = max(all_size);
    % 删除体积小的连通区域
    for i = 1:CC.NumObjects
        if all_size(i) < max_size
            trachea_3D(list{i}) = 0;
        end
    end
    % 再次膨胀、腐蚀
    trachea_3D = imdilate(trachea_3D, strel('cube', 4));
    trachea_3D = imerode(trachea_3D, strel('cuboid', [3, 2, 1]));

    %% 计算dice函数
    % 读入手动分割得到的肺部区域
    path = ['./data/coronacases_trachea_00', num2str(number), '.nii'];
    nii = load_nii(path);
    img_true = nii.img;
    trachea_3D_true = zeros(m, n, p);
    trachea_3D_true(:) = (img_true(:) > 0.6 * mean(img_true(:)));
    dice_value = dice(trachea_3D_true, trachea_3D);
    disp(['CT', num2str(number), '，dice: ', num2str(dice_value)]);
    
    %% 显示与保存
    figure(number);
    volshow(trachea_3D);   
    save(['./result_mat/coronacases_trachea_00', num2str(number), '.mat'], 'trachea_3D');
end

%% 在二值化图片上寻找最大连通域
function max_domain = find_max_domain(image)
    % 找到各个连通区域
    imLabel = bwlabel(image);
    % 求连通区域的大小
    stats = regionprops(imLabel, 'Area');    %求各连通域的大小
    area = cat(1, stats.Area);
    % 找到最大的连通区域
    index = find(area == max(area));
    max_domain = ismember(imLabel, index);
end