addpath(".\SliceBrowser");
addpath(".\NIfTI_20140122");

lung_segmentation(4);
lung_segmentation(5);
lung_segmentation(7);

function lung_segmentation(number)
    %% 读入待处理的CT数据
    path = ['./data/coronacases_org_00', num2str(number), '.nii'];
    nii = load_nii(path);
    img = nii.img;
    
    %% 二维切片图像处理
    [m, n, p] = size(img);
    lung_3D = zeros(m, n, p);
    for i = 1:p
        img_2D = img(:, :, i);  
        % 二值化
        img_2D = (img_2D > 0.6 * mean(mean(img_2D)));
        % 找到整个胸腔
        max_domain = find_max_domain(img_2D);
        chest = imfill(max_domain, 'hole');
        % 找出胸腔内部的影像，做图像腐蚀和膨胀
        in_chest = chest .* (~max_domain);
        se = strel('disk', 5);
        in_chest = imerode(in_chest, se);
        in_chest = imdilate(in_chest, se);
        % 找出左右两块肺部区域
        lung_2D_1 = find_max_domain(in_chest);
        lung_2D_2 = find_max_domain(in_chest - lung_2D_1);
        % 得到这一二维切片中肺部的影像
        lung_2D = lung_2D_1 + lung_2D_2;
        lung_3D(:, :, i) = lung_2D;
    end
    
    %% 三维形态学操作
    CC = bwconncomp(lung_3D, 26);
    list = CC.PixelIdxList;
    % 求所有连通区域的体积
    all_size = cellfun(@numel, list);
    max_size = max(all_size);
    % 删除体积小的连通区域
    for i = 1:CC.NumObjects
        if all_size(i) < 0.2 * max_size
            lung_3D(list{i}) = 0;
        end
    end

    %% 计算dice函数
    % 读入手动分割得到的肺部区域
    path = ['./data/coronacases_lung_00', num2str(number), '.nii'];
    nii = load_nii(path);
    img_true = nii.img;
    lung_3D_true = zeros(m, n, p);
    lung_3D_true(:) = (img_true(:) > 0.6 * mean(img_true(:)));
    dice_value = dice(lung_3D_true, lung_3D);
    disp(['CT', num2str(number), '，dice: ', num2str(dice_value)]);
    
    %% 显示与保存
    figure(number);
    volshow(lung_3D);   
    save(['./result_mat/coronacases_lung_00', num2str(number), '.mat'], 'lung_3D');
end

%% 在二值化图片上寻找最大连通域
function max_domain = find_max_domain(image)
    % 找到各个连通区域
    imLabel = bwlabel(image);
    % 求连通区域的大小
    stats = regionprops(imLabel, 'Area');
    area = cat(1, stats.Area);
    % 找到最大的连通区域
    index = find(area == max(area));
    max_domain = ismember(imLabel, index);
end