目录说明：

lung.m		肺部分割代码
trachea.m		气管分割代码
result_mat文件夹	肺分割和气管分割的结果，二值三维体数据，.mat文件