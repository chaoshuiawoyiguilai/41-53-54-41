%% 设置要处理的图片编号，三张图片分别为1，2，3
image_number = 1;


%% 读入图片
if (image_number == 1)
    image = imread('1.bmp');
elseif (image_number == 2)
    image = imread('2.bmp');
else
    image = imread('3.bmp');
end


%% 将图片划分为小块，进行DFT，并实现前景背景分割
%% 对于指纹区域，估计脊线方向和频率
% 图片大小
image_size = size(image);
image_height = image_size(1);
image_width = image_size(2);
% 分为小方块，两条边上小方块的个数
number_height = floor(image_height / 8);
number_width = floor(image_width / 8);
% 记录各个小块处理后得到的幅度谱中两个尖峰的角度和距离
angle = zeros(number_height , number_width);
distance = zeros(number_height, number_width);
% 标准差阈值和幅度谱阈值，用于区分前景与背景
std_threshold = 15;
DFTstd_threshold = 5000;
% 各个小方块的标准差、幅度是否达到阈值
meet_std = zeros(number_height , number_width);
meet_DFTstd = zeros(number_height , number_width);
% 逐个处理
for i = 1 : number_height
    for j = 1 : number_width
        if (i > 2 && j > 2 && i < number_height - 1 && j < number_height - 1)
            image_32by32 = double(image((i - 1) * 8 - 11:i * 8 + 12, (j - 1) * 8 - 11:j * 8 + 12));
        else
            % 补成32*32的小方格
            image_32by32 = double(image((i - 1) * 8 + 1:i * 8, (j - 1) * 8 + 1:j * 8));
            image_32by32 = padarray(image_32by32, [12, 12], 'both', 'replicate');
        end
        % 标准差
        the_std = std2(image_32by32);
        % 幅度谱
        DFT_magnitude = abs(fftshift(fft2(image_32by32)));
        % 幅度标准差
        ths_DFTstd = std2(DFT_magnitude);
        % 是否达到标准差阈值
        if (the_std < std_threshold)
            meet_std(i, j) = 0;
        else
            meet_std(i, j) = 1;
        end
        % 是否达到幅度标准差阈值
        if (ths_DFTstd > DFTstd_threshold)
            meet_DFTstd(i, j) = 0;
        else
            meet_DFTstd(i, j) = 1;
        end
        % 记录方向角和距离
        DFT_magnitude(16:18, 16:18) = 0;
        sorted = sort(DFT_magnitude(:));
        [row, column] = find(DFT_magnitude == sorted(end - 1));
        angle(i, j) = atand((column(1) - column(2)) / (row(1) - row(2)));
        distance(i, j) = sqrt((row(1) - column(2)) ^ 2 + (row(1) - row(2)) ^ 2);
    end
end

% 根据每一小块是否达到阈值，生成一个图像蒙版
% 这个蒙版的尺寸小于原图，其尺寸与脊线方向图相同，长宽均为原图的1/8
if (image_number == 1)
    mask_small = erode_dilate(meet_std, 1, 0);
elseif (image_number == 2)
    mask_small = erode_dilate(meet_DFTstd, 11, 12);
else
    mask_small = erode_dilate(meet_std, 12, 13);
end
% 生成和原图大小相同的蒙版
mask = imresize(mask_small, [image_size(1), image_size(2)], 'bicubic');
image_double = im2double(image);


%% 对方向图、频率图进行平滑
% 显示平滑之前的方向图
figure(1), imshow(image);
DrawDir(1, angle + 190 - 190 * mask_small, 8, 'r2');
% 首先对方向图进行平滑
angle_temp = zeros(number_height , number_width);
% 乘以2并化为弧度制
angle_temp = (angle / 180) * pi * 2;
angle_sin = sin(angle_temp);
angle_cos = cos(angle_temp);
% 分别对sin和cos进行滤波
filter = fspecial('Gaussian', [5, 5], 2);
angle_sin = imfilter(angle_sin, filter, 'replicate', 'same');
angle_cos = imfilter(angle_cos, filter, 'replicate', 'same');
% 根据sin和cos计算出对应角度
angle = 0.5 * atan2(angle_sin , angle_cos);
angle = 180 * angle / pi;
% 显示平滑之后的方向图
figure(2), imshow(image);
DrawDir(2, angle + 190 - 190 * mask_small, 8, 'r2');
% 对频率图进行平滑
frequence = zeros(number_height , number_width);
frequence = distance;
filter = fspecial('Gaussian', [3, 3], 2);
frequence = imfilter(frequence, filter);
frequence = uint8((frequence - min(min(frequence))) / (max(max(frequence)) - min(min(frequence))) * 255);


%% 对指纹进行滤波，得到增强图
image_enhanced = zeros(number_height * 8, number_width * 8);
% 逐个处理
for i = 1 : number_height
    for j = 1 : number_width
        if (mask_small(i, j) == 1)
            if (i > 2 && j > 2 && i < number_height - 1 && j < number_height - 1)
                image_32by32 = image((i - 1) * 8 - 11:i * 8 + 12, (j - 1) * 8 - 11:j * 8 + 12);
            else
                % 补成32*32的小方格
                image_32by32 = image((i - 1) * 8 + 1:i * 8, (j - 1) * 8 + 1:j * 8);
                image_32by32 = padarray(image_32by32, [12, 12], 'both', 'replicate');
            end
            wavelength = 32 / distance(i, j) + 3;
            if (wavelength < 2 || wavelength == inf || wavelength == -inf)
                image_enhanced((i - 1) * 8 + 1:i * 8, (j - 1) * 8 + 1:j * 8) = ones(8, 8);
                continue;
            end
            angle_gabor = angle(i, j) + 90;
            % gaobor滤波
            [magnitude, phase] = imgaborfilt(image_32by32, wavelength, angle_gabor);
            image_temp = magnitude .* cos(phase);
            image_enhanced_piece = image_temp(13:20, 13:20);
            % 二值化
            central = (max(max(image_enhanced_piece)) * 6 + min(min(image_enhanced_piece)) * 4) / 10;
            image_enhanced_piece = imbinarize(image_enhanced_piece, central);
            image_enhanced((i - 1) * 8 + 1:i * 8, (j - 1) * 8 + 1:j * 8) = image_enhanced_piece;
        else
            image_enhanced((i - 1) * 8 + 1:i * 8, (j - 1) * 8 + 1:j * 8) = ones(8, 8);
        end
    end
end 

% 此时已经得到增强图，但是稍显粗糙，对于增强图进行平滑和二值化
filter = fspecial('Gaussian', [4, 4], 8);
image_enhanced = imfilter(image_enhanced, filter, 'replicate', 'same');
if (image_number == 1)
    image_enhanced = imbinarize(image_enhanced, 0.4);
elseif (image_number == 2)
    image_enhanced = imbinarize(image_enhanced, 0.35);
else
    image_enhanced = imbinarize(image_enhanced, 0.3);
end
% 再进行腐蚀和膨胀，使指纹线条更连续、匀称
image_enhanced = 1 - image_enhanced;
image_enhanced = erode_dilate(double(image_enhanced), 1, 1);
image_enhanced = 1 - image_enhanced;


%% 一些显示和保存
hold on;
path = ['result\', num2str(image_number)];
% 显示方向图
% angle = angle + 190 - 190 * mask_small;
% figure(1), imshow(image);
% DrawDir(1, angle, 8, 'r2');
% 显示前景图
figure(3), imshow(image .* uint8(mask));
imwrite(image .* uint8(mask), [path, '_foreground.jpg']);
% 显示脊线增强图
figure(4), imshow(image_enhanced);
imwrite(image_enhanced, [path, '_enhanced.jpg']);
% 显示频率图
figure(5), imshow(frequence .* uint8(mask_small), 'border', 'tight', 'initialmagnification', 'fit');
imwrite(frequence .* uint8(mask_small), [path, '_frequence.jpg']);
