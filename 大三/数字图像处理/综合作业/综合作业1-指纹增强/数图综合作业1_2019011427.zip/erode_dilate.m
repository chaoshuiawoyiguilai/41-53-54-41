function [new_mask] = erode_dilate(mask, r1, r2)
    se = strel('disk', r1);
    mask = imerode(mask, se);
    se = strel('disk', r2);
    mask = imdilate(mask, se);
    new_mask = imbinarize(mask, 0.5);
end

