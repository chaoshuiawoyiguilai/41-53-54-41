main.m		主程序
erode_dilate.m	图像腐蚀和膨胀函数
DrawDir.m	老师提供的绘制方向图函数
result文件夹	图像处理结果